dbscheme

# need to enter your phpmyadmin credential. 
# insert servername username and password.
# no need to import db or create.

classUTCFormat 

# save data 
# check utc format version (additional info)

index 
  
# filter table 

filter 

# search filter query
# filter for all three option

script 

#  for draw filter entries 

 

